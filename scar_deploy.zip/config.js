module.exports = {
    mainToken: '9146384272:AAELkkWehFdtwUk6vBKyaLbol1OZbvD773s',
    
    S7: '@TEAMXXMAX',
    
    adminId: '8956772022',
    
    // ─── Main Links ───
    channel: 'https://t.me/TEAMXXMAX',
    group: 'https://t.me/TEAMXXMAX',
    
    youtube: '',
    
    forceJoinChannels: [
        { 
            id: '@TEAMXXMAX', 
            name: 'SCAR TEAM',
            url: 'https://t.me/TEAMXXMAX'
        }
    ],

    forceJoinGroups: [
        { 
            id: '@TEAMXXMAX', 
            name: 'SCAR TEAM',
            url: 'https://t.me/TEAMXXMAX'
        }
    ],
    
    // ─── Bot Info ───
    bot: '𝐒ᴄᴀʀ 𝐁ᴜɢ 𝐁ᴏᴛ',
    
    logo: './SY/Loves.jpg'
};
